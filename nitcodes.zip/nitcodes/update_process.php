<?php
$connect = mysqli_connect("localhost","root","","nit");

$id = $_POST['id'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$marks = $_POST['marks'];
$decision = $_POST['decision'];


$query = "UPDATE students SET firstname='$firstname', lastname='$lastname', marks='$marks',
decision='$decision' WHERE id='$id'";

$request = mysqli_query($connect,$query);

if($request)
{

    echo "Successfully Updated";
}else{
    echo "Fail to Update user information";
}

?>
