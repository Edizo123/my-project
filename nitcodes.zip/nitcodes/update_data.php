<?php

$connect  = mysqli_connect("localhost","root","", "nit");
$id = $_GET['id'];
$select = mysqli_query($connect,"SELECT * from students WHERE id='$id'");
while($row = mysqli_fetch_array($select)){
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Data</title>
</head>
<body>
    <form action="update_process.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
        <label for="">FirstName</label><br>
        <input type="text" name="firstname" value="<?php echo $row['firstname']?>"><br>
        <label for="">LastName</label><br>
        <input type="text" name="lastname" value="<?php echo $row['lastname']?>"><br>
        <label for="">Marks</label><br>
        <input type="number" name="marks" value="<?php echo $row['marks']?>"><br>
        <label for="">Decision</label><br>
        <input type="text" name="decision" value="<?php echo $row['decision']?>"><br><br>

    <input type="submit" value="Update">
    </form>
    <?php } ?>
</body>
</html>