<?php

$connect = mysqli_connect("localhost","root","","nit");

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$marks = $_POST['marks'];
$decision = $_POST['decision'];


$query = "INSERT INTO students(firstname,lastname,marks,decision) VALUES('$firstname','$lastname','$marks','$decision')";

$sql = mysqli_query($connect,$query);

if($sql)
{
    echo "Data Successfully Inserted";
}else{
    echo "Data not Inserted";
}


?>