<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inserting Data in Database</title>
</head>
<body>
    <form action="insertdata.php" method="POST">
        <label for="">FirstName</label><br>
        <input type="text" name="firstname"><br>
        <label for="">LastName</label><br>
        <input type="text" name="lastname"><br>
        <label for="">Marks</label><br>
        <input type="number" name="marks"><br>
        <label for="">Decision</label><br>
        <select name="decision"><br>
            <option value="Pass">Pass</option>
            <option value="Fail">Fail</option>
    </select><br><br>
    <input type="submit" value="Register">
    </form>
    
</body>
</html>