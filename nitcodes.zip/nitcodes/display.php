<?php
$connect = mysqli_connect("localhost","root","","nit");
$query = mysqli_query($connect,"SELECT * from students");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table</title>
</head>
<body>
  
    <table border="1">
        <thead>
            <th>Id</th>
            <th>FirstName</th>
            <th>LastName</th>
            <th>Marks</th>
            <th>Decision</th>
            <th colspan="2">Action</th>
        </thead>
        <?php
    while($row = mysqli_fetch_array($query)){ 
    ?>
        <tbody>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['firstname']; ?></td>
            <td><?php echo $row['lastname']; ?></td>
            <td><?php echo $row['marks']; ?></td>
            <td><?php echo $row['decision']; ?></td>
            <td><a href="update_data.php?id=<?php echo $row['id']; ?>">Update</a></td>
            <td>Delete</td>
        </tbody>
        <?php } ?>
</table>
</body>
</html>